"""Dialogs module"""

# __all__ = [
#     'MainDialog',
#     'AuthDialog',
#     'WelcomeDialog',
#     'UtilsDialog',
#     'TelegramRegistrationDialog'
# ]
